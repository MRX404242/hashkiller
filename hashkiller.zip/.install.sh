apt update & apt upgrade -y
pkg install nodejs -y
npm install -g bash-obfuscate
pip install uncompyle6
clear
rm -rf .install.sh
